import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np
from io import BytesIO


def get_3d():
    # 1. 创建图(绘制环境)
    figure = plt.figure('3D图形', figsize=(8, 6))

    # 2. 创建3D坐标系（直接创建，使用Figure中的函数创建：这里使用函数）
    ax = figure.add_axes([0.1, 0.1, 0.8, 0.8], projection='3d')

    # 使用线条绘制马鞍面
    x, y = np.mgrid[-5:5:100j, -5:5:100j]
    z = (x**2 - y**2)/2

    colors = plt.cm.get_cmap('cool')
    ax.scatter(x.flat, y.flat, z.flat, label='3D点', s=1, c=z.flat, cmap=colors)

    ax.grid(b=False)   # 网格线

    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    return buffer.getvalue()