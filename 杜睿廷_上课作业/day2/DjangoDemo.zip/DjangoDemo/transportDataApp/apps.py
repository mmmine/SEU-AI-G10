from django.apps import AppConfig


class TransportdataappConfig(AppConfig):
    name = 'transportDataApp'
