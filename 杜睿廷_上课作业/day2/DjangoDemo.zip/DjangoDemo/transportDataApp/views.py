from django.shortcuts import render
from django.shortcuts import HttpResponse
from transportDataApp import plot3D
# Create your views here.
def transportText(request):
    data="{university:'SEU',name:'杜睿廷',group:'10组',source:'数据来自Django'}"
    return HttpResponse(data)

def transportImg(request):
    img=plot3D.get_3d()
    return HttpResponse(content=img,content_type="image/png")